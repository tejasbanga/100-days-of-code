var longi="",lati="";
var imager;
var imgcrtr;
var a;
navigator.geolocation.getCurrentPosition(function(position)
{
longi=position.coords.longitude;
lati=position.coords.latitude; 
});
$(document).ready(function(){
$.getJSON("https://fcc-weather-api.glitch.me/api/current?lon="+longi+"&"+"lat="+lati,function(json)
       {
   a=json;
  $("#temp").html(a.main.temp);
  imager=a.weather[0].icon;
  imgcrtr=document.querySelector("img");
  imgcrtr.src=imager;
});
  function unitToggler()
{
  var ab;
  ab=$("#unitT");
console.log(ab.value);
}

});





